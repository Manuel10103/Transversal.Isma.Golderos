package com.casino.backend.controller;

import com.casino.backend.service.ApuestaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/apuesta")
public class ApuestaController {

    @Autowired
    private ApuestaService apuestaService;

    @PostMapping("/realizar/{id}/{monto}/{gana}/{ganancia}")
    public String realizarApuesta(@PathVariable Long id, @PathVariable BigDecimal monto,
                                  @PathVariable boolean gana, @PathVariable BigDecimal ganancia) {
        return apuestaService.realizarApuesta(id, monto, gana, ganancia);
    }
}
