package com.casino.backend.service;

import com.casino.backend.entity.UsuarioEntity;
import com.casino.backend.repo.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    
    public UsuarioEntity registrarUsuario(UsuarioEntity usuario) {
        
        Optional<UsuarioEntity> usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent()) {
            throw new RuntimeException("El usuario con este email ya existe.");
        }

        return usuarioRepository.save(usuario);
    }

    
    public UsuarioEntity validarCredenciales(String email, String contraseya) {
        return usuarioRepository.findByEmail(email)
                .filter(u -> u.getContraseya().equals(contraseya)) 
                .orElseThrow(() -> new RuntimeException("Credenciales incorrectas."));
    }
public boolean actualizarSaldo(Long idUsuario, BigDecimal monto, boolean esDeposito) {
    Optional<UsuarioEntity> usuarioOpt = usuarioRepository.findById(idUsuario);
    if (usuarioOpt.isPresent()) {
        UsuarioEntity usuario = usuarioOpt.get();
        BigDecimal saldoActual = usuario.getSaldo();
        BigDecimal nuevoSaldo = esDeposito ? saldoActual.add(monto) : saldoActual.subtract(monto);

        if (nuevoSaldo.compareTo(BigDecimal.ZERO) < 0) {
            return false; // Saldo insuficiente
        }

        usuario.setSaldo(nuevoSaldo);
        usuarioRepository.save(usuario);
        return true;
    }
    return false;
}

    
}
