package com.casino.backend.repo;

import com.casino.backend.entity.ApuestaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ApuestaRepository extends JpaRepository<ApuestaEntity, Long> {
}
