package com.casino.backend.service;

import com.casino.backend.entity.ApuestaEntity;
import com.casino.backend.entity.ResultadoApuesta;
import com.casino.backend.entity.UsuarioEntity;
import com.casino.backend.repo.ApuestaRepository;
import com.casino.backend.repo.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

@Service
public class ApuestaService {

    @Autowired
    private ApuestaRepository apuestaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public String realizarApuesta(Long idUsuario, BigDecimal monto, boolean gana, BigDecimal ganancia) {
        UsuarioEntity usuario = usuarioRepository.findById(idUsuario).orElse(null);
        if (usuario == null) return "Usuario no encontrado";

        if (usuario.getSaldo().compareTo(monto) < 0) {
            return "Saldo insuficiente";
        }

        // Crear apuesta
        ApuestaEntity apuesta = new ApuestaEntity();
        apuesta.setUsuario(usuario);
        apuesta.setMonto(monto);
        apuesta.setResultado(gana ? ResultadoApuesta.GANADO : ResultadoApuesta.PERDIDO);
        apuesta.setGanancia(gana ? ganancia : BigDecimal.ZERO);

        // Actualizar saldo
        BigDecimal saldoFinal = usuario.getSaldo().subtract(monto);
        if (gana) {
            saldoFinal = saldoFinal.add(ganancia);
        }
        usuario.setSaldo(saldoFinal);

        usuarioRepository.save(usuario);
        apuestaRepository.save(apuesta);
        return "Apuesta registrada";
    }
}
