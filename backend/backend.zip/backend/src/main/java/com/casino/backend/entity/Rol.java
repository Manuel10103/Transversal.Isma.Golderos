package com.casino.backend.entity;

public enum Rol {
    NORMAL, PREMIUM;
}
