package com.casino.backend.entity;

	public enum ResultadoApuesta {
	    GANADO,
	    PERDIDO,
	    EMPATE
	}


